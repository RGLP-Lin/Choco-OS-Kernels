// kernel.c

void write_char(char c, int row, int col);
void kernel_main() {
    const char *message = "Hello, World!";
    int i = 0;

    // Write each character to the screen
    while (message[i] != '\0') {
        write_char(message[i], 12, i);  // Print in row 12, column 'i'
        i++;
    }
}

void write_char(char c, int row, int col) {
    // Video memory starts at 0xB8000
    unsigned short *video_memory = (unsigned short *)0xB8000;
    int offset = (row * 80) + col;  // Assuming 80 columns
    video_memory[offset] = (unsigned short)(c | 0x0F00); // White on black
}
