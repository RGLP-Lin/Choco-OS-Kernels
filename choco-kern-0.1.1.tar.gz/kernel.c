void kernel_main(void) {
    char *video = (char*)0xb8000;
    const char *msg = "Hello from Chocolate OS kernel!";
    for (int i = 0; msg[i]; ++i) {
        video[i * 2] = msg[i];
        video[i * 2 + 1] = 0x1E; // Yellow on blue
    }
    for (;;); // Infinite loop
}